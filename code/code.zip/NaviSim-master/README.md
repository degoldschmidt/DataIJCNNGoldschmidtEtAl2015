NaviSim
=======

A simulation of neurally inspired control mechanisms for navigating a 2-D agent
